"""Acme shared helpers (internal)."""

import re


def slugify(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def origin() -> str:
    return "internal 1.4.0"
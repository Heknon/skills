"""Placeholder published to the public index under this name."""


def slugify(text: str) -> str:
    return text


def origin() -> str:
    return "public 9.0.0"
